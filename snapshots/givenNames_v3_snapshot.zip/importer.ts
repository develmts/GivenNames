
// importer.ts
// Versio 3.1

import fs from 'fs';
// import { inferGender } from './genderInference';
import { inferGenderFromMetadata , inferGender } from './genderInference';


export function importNamesFromFile(filePath: string) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n').filter(line => line.trim() !== '');
  
  let metadata: any = {};
  let startIndex = 0;

  if (lines[0].startsWith('#')) {
    try {
      metadata = JSON.parse(lines[0].substring(1).trim());
      startIndex = 1;
    } catch (e) {
      console.warn('⚠️ Failed to parse metadata, ignoring.');
    }
  }

  const names: { name: string, gender: string }[] = [];

  for (let i = startIndex; i < lines.length; i++) {
    const name = lines[i].trim();
    if (name === '') continue;

    // let gender = metadata.gender || inferGender(name);
    // Assumeix que `metadata` ja ha estat llegida prèviament
    const { gender } = inferGenderFromMetadata(name, metadata);

    names.push({ name, gender });
  }

  return { metadata, names };
}
