// genderTerms.ts — generat automàticament
// Taula de termes per inferència de gènere per idioma, incloent singulars i plurals

export const GENDER_TERMS_BY_LOCALE: Record<string, { male: string[]; female: string[], neutral:string[]}> = {
  "es": {
    male: ["niño", "niños", "chico", "chicos", "hombre", "hombres", "varón", "varones"],
    female: ["niña", "niñas", "chica", "chicas", "mujer", "mujeres", "hembra", "hembras"],
    neutral: ["unisex"]
  },
  "ca": {
    male: ["nen", "nens", "noi", "nois", "home", "homes"],
    female: ["nena", "nenes", "noia", "noies", "dona", "dones"],
    neutral: ["unisex"]
  },
  "en": {
    male: ["boy", "boys", "man", "men", "male", "males"],
    female: ["girl", "girls", "woman", "women", "female", "females"],
    neutral: ["unisex"]
  },
  "fr": {
    male: ["garçon", "garçons", "homme", "hommes", "mâle", "mâles"],
    female: ["fille", "filles", "femme", "femmes", "femelle", "femelles"],
    neutral: ["unisex"]
  },
  "it": {
    male: ["ragazzo", "ragazzi", "uomo", "uomini", "maschio", "maschi"],
    female: ["ragazza", "ragazze", "donna", "donne", "femmina", "femmine"],
    neutral: ["unisex"]
  },
  "pt": {
    male: ["menino", "meninos", "rapaz", "rapazes", "homem", "homens"],
    female: ["menina", "meninas", "rapariga", "raparigas", "mulher", "mulheres"],
    neutral: ["unisex"]
  },
  "de": {
    male: ["junge", "jungen", "mann", "männer", "kerl", "kerle"],
    female: ["mädchen", "mädchen", "frau", "frauen", "weiblich"],
    neutral: ["unisex"]
  },
  // Default / fallback
  "und": {
    male: ["boy", "boys", "man", "men", "male", "males"],
    female: ["girl", "girls", "woman", "women", "female", "females"],
    neutral: ["unisex"]
  }
 
};
