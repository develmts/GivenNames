// versio 3.1
// webcrawler.ts — updated: includes diagnostic name validation

import { inferGender, inferGenderFromURI, inferGenderFromNameList } from './genderInference';
import { chromium } from 'playwright';
import { writeFile } from 'fs/promises';
import * as fs from 'fs';
import minimist from 'minimist';
import { extractValidNames , extractPotentialNamesFromHTML} from './nameExtractor';
import { JSDOM } from 'jsdom';


export interface CrawlerSeed {
  locale: string;
  gender?: string;
  url: string;
}

export interface PageMetadata {
  locale: string;
  gender?: string;
  source_url: string;
  source_slug: string;
}

export interface CrawlResult {
  names: string[];
  metadata: PageMetadata[];
}

export interface CrawlOptions {
  seeds: CrawlerSeed[];
  outputBasePath?: string;
  rateLimitMs?: number;
  headed?: boolean;
  maxPages?: number;
}

// import { NEGATIVE_WORDS } from './non-names';

function toUTF8(str: string): string {
  return Buffer.from(str, 'utf-8').toString();
}

function slugify(pUrl: string): string {
  try {
    const url = new URL(pUrl);
    const cleanPath = url.pathname.replace(/\/+$/, '').replace(/\/+/g, '-').replace(/\..*$/g, '');
    return `${url.hostname.replace(/\./g, '-')}-${cleanPath}`
      .replace(/--+/g, '-')
      .replace(/\:/g, '-'
      .replace(/(^-|-$)/g, '')
      .toLowerCase())
  } catch {
    return '';
  }
}

export class WebCrawler {
  constructor(private config: CrawlOptions) {}

  private async extractNamesFromPage(seed: CrawlerSeed): Promise<{ names: string[]; metadata: PageMetadata }>{
    const browser = await chromium.launch({ headless: !this.config.headed });
    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto(seed.url, { waitUntil: 'networkidle' }); // ✅ esperem a que tot carregui
    const html = await page.content() ?? '';

    const dom = new JSDOM(html, {
      url: seed.url
    });


    // const dom = new JSDOM(html);
    const document = dom.window.document;

    const validNames = extractPotentialNamesFromHTML(document);
    const inferredGender = seed.gender ?? inferGenderFromNameList(validNames, seed.locale).gender;

    await page.close();
    await browser.close();

    const meta = {
      locale: seed.locale,
      gender: inferredGender,
      source_url: seed.url,
      source_slug: slugify(seed.url),
    };

    return {
      names: validNames,
      metadata: meta,
    }; 
  }

  async run(): Promise<CrawlResult> {
    const allMeta: PageMetadata[] = [];
    const allResults: { names: string[]; metadata: PageMetadata }[] = [];

    for (const seed of this.config.seeds.slice(0, this.config.maxPages ?? 1)) {
      const result = await this.extractNamesFromPage(seed);
      allResults.push(result);
      if (this.config.rateLimitMs)
        await new Promise(r => setTimeout(r, this.config.rateLimitMs));
    }

    if (this.config.outputBasePath) {
      for (const { names, metadata } of allResults) {
        const shortGender = (metadata.gender ?? 'u').substring(0, 1);
        const fileName = `${this.config.outputBasePath}/${metadata.locale}-${shortGender}-${metadata.source_slug}.txt`;
        const header = `# locale=${metadata.locale} gender=${metadata.gender} source=${metadata.source_url}`;
        const body = names.join('\n');
        if (!names || names.length === 0) {
          console.warn(`⚠️ No names to save for ${fileName}`);
        }
        // Debug info
        // console.log(`[✍️ WRITE] ${fileName}`);
        const fullText=`${header}\n${body}\n` 
        // console.log(`[📄 CONTENT PREVIEW]\n${fullText.slice(0, 300)}...`);

        try {
          // const handle = fs.openSync(fileName,"w");
          // await writeFile(fileName, `${header}\n${body}\n`, 'utf-8');
          await writeFile(fileName, 
            `${header}\n${body}\n`, 
            {
              flag: "w", 
              encoding: "utf-8",
              flush: true
            });
        
        }catch(err) {
          console.error(`❌ Error saving file ${fileName}: ${err.message}`);
          continue;
        }
        // console.log(`💾 Saved ${names.length} names to ${fileName} `);
        // console.log(fs.readFileSync(fileName).toString())

      }
    }

    return { names: [], metadata: allMeta };
  }

  static async runFromCLI() {
    const argv = minimist(process.argv.slice(2));
    const seedsFile = argv.seeds;
    const outputPath = argv.out || './out';

    if (!seedsFile || !fs.existsSync(seedsFile)) {
      console.error('❌ --seeds <file> is required');
      process.exit(1);
    }

    const lines = fs.readFileSync(seedsFile, 'utf-8').split(/\r?\n/);
    const seeds: CrawlerSeed[] = [];
    let currentLocale = 'und';

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('#')) {
        const match = trimmed.match(/#\s*locale:\s([a-zA-Z\-]+)/);
        if (match) currentLocale = match[1];
        continue;
      } else if (trimmed !== '') {
        const inferred = inferGenderFromURI(trimmed, currentLocale);
        // console.log("inferred from URI:", inferred)
        seeds.push({ locale: currentLocale, url: trimmed , gender : inferred.gender });
      }
    }

    const crawler = new WebCrawler({
      seeds,
      outputBasePath: outputPath,
      rateLimitMs: 500,
      headed: false,
      maxPages: 5,
    });

    await crawler.run();
  }
}

if (process.argv.includes('--cli')) {
  WebCrawler.runFromCLI();
}
