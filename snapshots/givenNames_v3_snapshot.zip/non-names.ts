export const NEGATIVE_WORDS = [
  "nomix",
  "nalcolatori",
  "nuriosità",
  "nomignoli",
  "pets",
  "accedi",
  "registrati",
  "posizione",
  "tendenza",
  "browserhappy","login", "register", "signup", "cookie", "home", "inicio", "terms",
  "privacy", "faq", "sitemap", "contact", "language", "subscribe", "profile",
  "newsletter",
  "iscrivimi",
  "sondagio",
  "social",
  "pubblicita",
  "disclaimer",
  "privacy",
  "contatti"
];
 