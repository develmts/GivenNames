// nameExtractor.ts — new extractor with diagnostic validation
import { NEGATIVE_WORDS } from './non-names';

export interface ValidationResult {
  valid: boolean;
  reasons: string[];
}

export function isValidName(text: string): ValidationResult {
  const cleaned = text.trim();
  const reasons: string[] = [];

  if (cleaned === '') reasons.push("empty");
  const words = cleaned.split(/\s+/);
  if (words.length > 3) reasons.push("too many words");
  if (!/^[A-Z]/.test(words[0])) reasons.push("does not start with capital letter");
  if (words.filter(w => /^[A-Z]/.test(w)).length > 1) reasons.push("multiple capitalized words");
  if (NEGATIVE_WORDS.includes(cleaned.toLowerCase())) reasons.push("matches negative word list");
  if (!/^\p{Lu}[\p{L}\p{M}\-' ]+$/u.test(cleaned)) reasons.push("fails regex");

  return {
    valid: reasons.length === 0,
    reasons
  };
}

export function extractValidNames(candidates: string[]): string[] {
  const validNames: string[] = [];

  for (const name of candidates) {
    const result = isValidName(name);
    if (result.valid) {
      validNames.push(name);
    } else {
      console.log(`❌ Rejected: "${name}" — reasons: ${result.reasons.join(', ')}`);
    }
  }

  return validNames;
}