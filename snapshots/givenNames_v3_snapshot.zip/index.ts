// index.ts — uses GivenNamesORM

import { GivenNamesORM } from './db/GivenNamesORM';
import path from 'path';

const orm = new GivenNamesORM(path.join(__dirname, 'db.sqlite'));


// placeholder

console.log('All names:');
console.log(orm.getAllNames());

console.log('Names marked as saints:');
console.log(orm.getNamesWhereSaint());