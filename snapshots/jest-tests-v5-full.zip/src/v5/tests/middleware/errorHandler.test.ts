describe('errorHandler', () => { it.todo('handles errors') })
