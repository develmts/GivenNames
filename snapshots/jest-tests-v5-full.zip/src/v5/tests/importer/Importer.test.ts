import { Importer } from "../../importer"
describe("Importer", () => {
  it("should run from config without throwing", async () => {
    const config: any = { rootPath: ".", verbose: false }
    await expect(Importer.runFromConfig(config)).resolves.not.toThrow()
  })
})
