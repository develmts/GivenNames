import { semImport } from "../../importSemantic"
describe("semImport", () => {
  it("should execute without errors on empty dir", () => {
    expect(() => semImport(".")).not.toThrow()
  })
})
