// nameExtractor.ts — extracted from webcrawlerV3.ts (2025-09-11)
import { NEGATIVE_WORDS } from './non-names';

export function isValidName(text: string): boolean {
  const cleaned = text.trim();
  const words = cleaned.split(/\s+/);
  let ret = false;

  if (words.length > 3 || words.length === 0) ret = false;
  else if (/^[^A-Z]/.test(words[0])) ret = false; // must start with uppercase
  else if (words.filter(w => /^[A-Z]/.test(w)).length > 1) ret = false; // only one initial cap
  else if (NEGATIVE_WORDS.includes(cleaned.toLowerCase())) ret = false;
  else ret = /^[\p{Lu}][\p{L}\p{M}\-' ]+$/u.test(cleaned);

  return ret;
}

export function extractCandidateNamesFromHTML(html: string): string[] {
  const matches = html.match(/>([A-Z][\p{L}\p{M}'\-]{1,})</gu);
  const names = new Set<string>();
  for (const m of matches || []) {
    const name = m.slice(1, -1).trim();
    if (name.length > 1) names.add(name);
  }
  return [...names];
}