
// importerNG.ts
import fs from 'fs';
import { inferGender } from './inferGender';

export function importNamesFromFile(filePath: string) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n').filter(line => line.trim() !== '');
  
  let metadata: any = {};
  let startIndex = 0;

  if (lines[0].startsWith('#')) {
    try {
      metadata = JSON.parse(lines[0].substring(1).trim());
      startIndex = 1;
    } catch (e) {
      console.warn('⚠️ Failed to parse metadata, ignoring.');
    }
  }

  const names: { name: string, gender: string }[] = [];

  for (let i = startIndex; i < lines.length; i++) {
    const name = lines[i].trim();
    if (name === '') continue;

    let gender = metadata.gender || inferGender(name);
    names.push({ name, gender });
  }

  return { metadata, names };
}
