import { UserService } from "../../services/UserService"
import { app } from "../../server"
import request from "supertest"

jest.mock("../../services/UserService")

describe("routesUsers (unit)", () => {
  it("POST /users/update updates password", async () => {
    (UserService.updatePassword as jest.Mock).mockResolvedValue(undefined)
    const res = await request(app).post("/users/update").send({ oldPassword: "a", newPassword: "b" })
    expect(res.status).toBe(200)
    expect(res.body.message).toBe("Password updated")
  })
})
