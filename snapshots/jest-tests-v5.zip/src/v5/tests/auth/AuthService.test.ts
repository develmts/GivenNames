import { AuthService } from "../../services/ApiService/AuthService"

describe("AuthService", () => {
  it("should generate tokens on login", async () => {
    const result = await AuthService.login("testuser", "password")
    expect(result).toHaveProperty("accessToken")
    expect(result).toHaveProperty("refreshToken")
  })

  it("should refresh tokens with valid refresh token", async () => {
    const login = await AuthService.login("testuser", "password")
    const refreshed = await AuthService.refresh(login.refreshToken)
    expect(refreshed).toHaveProperty("accessToken")
  })

  it("should return null for invalid refresh token", async () => {
    const result = await AuthService.refresh("invalid.token")
    expect(result).toBeNull()
  })
})
