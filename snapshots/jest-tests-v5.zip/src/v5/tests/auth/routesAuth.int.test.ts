import { server } from "../../server"
import request from "supertest"

describe("routesAuth (integration)", () => {
  it("POST /auth/login returns tokens", async () => {
    const res = await request(server).post("/auth/login").send({ username: "test", password: "pass" })
    expect(res.status).toBe(200)
    expect(res.headers).toHaveProperty("x-access-token")
    expect(res.headers["set-cookie"]).toBeDefined()
  })
})
