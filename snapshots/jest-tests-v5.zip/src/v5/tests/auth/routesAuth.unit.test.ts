import { AuthService } from "../../services/ApiService/AuthService"
import { app } from "../../server"
import request from "supertest"

jest.mock("../../services/ApiService/AuthService")

describe("routesAuth (unit)", () => {
  it("POST /auth/login should return access token", async () => {
    (AuthService.login as jest.Mock).mockResolvedValue({
      accessToken: "fake-access",
      refreshToken: "fake-refresh"
    })

    const res = await request(app).post("/auth/login").send({ username: "a", password: "b" })
    expect(res.status).toBe(200)
    expect(res.body).toHaveProperty("message")
    expect(res.headers).toHaveProperty("x-access-token")
  })
})
