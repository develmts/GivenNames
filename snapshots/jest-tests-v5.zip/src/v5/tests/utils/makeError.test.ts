import { makeError } from "../../services/ApiService/utils/HttpErrors"

describe("makeError", () => {
  it("should create a 401 error with WWW-Authenticate", () => {
    const err = makeError(401, "Unauthorized")
    expect(err.status).toBe(401)
    expect(err.headers).toHaveProperty("WWW-Authenticate")
  })

  it("should create a 403 error", () => {
    const err = makeError(403, "Forbidden")
    expect(err.status).toBe(403)
  })

  it("should create a 404 error", () => {
    const err = makeError(404, "Not Found")
    expect(err.status).toBe(404)
  })
})
