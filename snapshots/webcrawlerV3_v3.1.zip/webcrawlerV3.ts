// webcrawlerV3.ts — revision 2025-09-10 (soroll filter improved)
import { inferGender, inferGenderFromNameList } from './genderInferenceV3';
import { chromium } from 'playwright';
import { writeFile } from 'fs/promises';
import * as fs from 'fs';
import minimist from 'minimist';

export interface CrawlerSeed {
  locale: string;
  gender?: string;
  url: string;
}

export interface PageMetadata {
  locale: string;
  gender?: string;
  source_url: string;
  source_slug: string;
}

export interface CrawlResult {
  names: string[];
  metadata: PageMetadata[];
}

export interface CrawlOptions {
  seeds: CrawlerSeed[];
  outputBasePath?: string;
  rateLimitMs?: number;
  headed?: boolean;
  maxPages?: number;
}

import { NEGATIVE_WORDS } from './non-names';

function isValidName(text: string): boolean {
  const cleaned = text.trim();
  const words = cleaned.split(/\s+/);
  let ret = false

  if (words.length > 3 || words.length === 0) ret = false;
  else if (/^[^A-Z]/.test(words[0])) ret = false; // must start with uppercase
  else if (words.filter(w => /^[A-Z]/.test(w)).length > 1) ret = false; // only one initial cap
  else if (NEGATIVE_WORDS.includes(cleaned.toLowerCase())) ret = false;
  else
    ret = /^[\p{Lu}][\p{L}\p{M}\-' ]+$/u.test(cleaned);
  console.log("isValidName", `"${text}" -> ${ret}`) 
  return ret
}

function toUTF8(str: string): string {
  return Buffer.from(str, 'utf-8').toString();
}

function slugify(pUrl: string): string {
  try {
    //const url = new URL("https://a.b.com:87/path/to/resource.html?query=1#frag");
    const url = new URL(pUrl)
    const cleanPath = url.pathname.replace(/\/+$/,'').replace(/\/+/g, '-').replace(/\..*$/g, '')
    return `${url.hostname.replace(/\./g, '-')}-${cleanPath}`
      .replace(/--+/g, '-')
      .replace(/(^-|-$)/g, '')
      .toLowerCase();
  } catch {
    return '';
  }
}



export class WebCrawlerV3 {
  constructor(private config: CrawlOptions) {}
  
  private async extractNamesFromPage(seed: CrawlerSeed): Promise<{ names: string[], metadata: PageMetadata }> {
    const browser = await chromium.launch({ headless: !this.config.headed });
    const context = await browser.newContext();
    const page = await context.newPage();
    // const allNames = new Set<string>();
    let inferredGender: string = ""
    
    try {
      console.log(`🔍 Crawling ${seed.url}`);
      await page.goto(seed.url, { timeout: 30000 });
      const html = await page.content() ?? '';
      const matches = html.match(/>([A-Z][\p{L}\p{M}'\-]{1,})</gu);
      const names = new Set<string>();
      for (const m of matches || []) {
        const name = m.slice(1, -1).trim();
        if (name.length > 1) names.add(toUTF8(name));
      }
      inferredGender = seed.gender ?? inferGenderFromNameList([...names], seed.locale);

      const meta={
        locale: seed.locale ,
        gender: inferredGender,
        source_url: seed.url,
        source_slug: slugify(seed.url),
      };

      return {
        names: names.size > 0 ? [...names].filter(isValidName) : [],
        metadata: meta
      };

    } catch (err) {
      console.error(`⚠️ Error: ${err.message}`);
    } finally {
      await page.close();
      await browser.close();
    }
  }

  async run(): Promise<CrawlResult> {
    const allNames = new Set<string>();
    const allMeta: PageMetadata[] = [];
    const allResults: { names: string[]; metadata: PageMetadata }[] = [];

    for (const seed of this.config.seeds.slice(0, this.config.maxPages ?? 1)) {
      const result = await this.extractNamesFromPage(seed);
      allResults.push(result);
      // result.names.forEach(n => allNames.add(n));
      // allMeta.push(result.metadata);
      if (this.config.rateLimitMs) 
        await new Promise(r => setTimeout(r, this.config.rateLimitMs));
    }

    if (this.config.outputBasePath) {
      for (const { names, metadata } of allResults) {
        const fileName = `${this.config.outputBasePath}/${metadata.gender ?? "u"}-${metadata.locale}-${metadata.source_slug}.txt`;
        const header = `# gender=${metadata.gender ?? 'unknown'} locale=${metadata.locale} source=${metadata.source_url}`;
        const body = names.join('\n');
        await writeFile(fileName, `${header}\n${body}\n`, 'utf-8');
        console.log(`💾 Saved ${names.length} names to ${fileName}`);
      }      
    }

    return { names: [...allNames], metadata: allMeta };
  }

  static async runFromCLI() {
    const argv = minimist(process.argv.slice(2));
    const seedsFile = argv.seeds;
    const outputPath = argv.out || './out';


    if (!seedsFile || !fs.existsSync(seedsFile)) {
      console.error('❌ --seeds <file> is required');
      process.exit(1);
    }

    const lines = fs.readFileSync(seedsFile, 'utf-8').split(/\r?\n/)
    // .filter((l:string) => { return !l.startsWith('#')})
    // .filter(Boolean)
    // const seeds: CrawlerSeed[] = lines.map((line:string) => {
    //   let loc = "und"
    //   if (line.startsWith('#')) {
    //     // find iso code
    //     const match = line.match(/#\s*locale=([a-zA-Z\-]+)/)
    //     if (match) {
    //       loc = match[1]
    //     }
    //   }  
    //   return {
    //     locale: loc,
    //     url: line.trim()
    //     }
    // });
    const seeds: CrawlerSeed[] = []
    let currentLocale = 'und';
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('#')) {
        const match = trimmed.match(/#\s*locale:\s([a-zA-Z\-]+)/);
        if (match) currentLocale = match[1];
        console.log("Locale match", match, trimmed)
        continue;
      }else if (trimmed != ''){
        //if its not meta or blank, its a url
        seeds.push({ locale: currentLocale, url: trimmed });
      }
    }

    console.log("Seeds", seeds)

    const crawler = new WebCrawlerV3({
      seeds,
      outputBasePath: outputPath,
      rateLimitMs: 500,
      headed: false,
      maxPages: 5
    });

    await crawler.run();
  }
}

if (process.argv.includes('--cli')) {
  WebCrawlerV3.runFromCLI();
}

// Run with: ts-node webcrawlerV3.ts --cli --seeds seeds.txt --out ./out
// genderInferenceV3.ts — revision 2024-06-10 (added inferGenderFromNameList)