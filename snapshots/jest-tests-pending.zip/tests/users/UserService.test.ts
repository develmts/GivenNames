import { UserService } from "../../src/v5/services/UserService"

describe("UserService", () => {
  it("should update password with valid old password", async () => {
    const userId = await UserService.createUser("bob", "oldpass", ["user"])
    await expect(UserService.updatePassword(userId, "oldpass", "newpass")).resolves.not.toThrow()
  })

  it("should throw error with wrong old password", async () => {
    const userId = await UserService.createUser("alice", "pass", ["user"])
    await expect(UserService.updatePassword(userId, "wrong", "newpass")).rejects.toThrow()
  })
})
