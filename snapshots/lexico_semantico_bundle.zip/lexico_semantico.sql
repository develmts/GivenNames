-- lexico_semantico.sql
-- Catálogo de léxicos para clasificar semántica de nombres.
-- Requiere que exista la tabla Semantica (con Semantica_Id y Clave).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS LexicoSemantico (
    Lexico_Id        INTEGER PRIMARY KEY AUTOINCREMENT,
    Semantica_Id     INTEGER NOT NULL,
    FormaNormalizada TEXT    NOT NULL,  -- minúsculas, sin diacríticos (NFKD - \p{M})
    FormaOriginal    TEXT,              -- opcional (con tildes/caso original)
    Idioma           TEXT,              -- ISO 639-1 (ej. 'es','en','fr') o NULL/'' si desconocido
    Peso             REAL    NOT NULL DEFAULT 1.0,  -- importancia relativa (≥0)
    Negativo         INTEGER NOT NULL DEFAULT 0 CHECK (Negativo IN (0,1)), -- 1 = lista negativa (resta puntos)
    Fuente           TEXT,
    Nota             TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at       TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (Semantica_Id, FormaNormalizada, COALESCE(Idioma,''), Negativo),
    FOREIGN KEY (Semantica_Id) REFERENCES Semantica (Semantica_Id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_lexico_norm    ON LexicoSemantico (FormaNormalizada);
CREATE INDEX IF NOT EXISTS idx_lexico_sem     ON LexicoSemantico (Semantica_Id);
CREATE INDEX IF NOT EXISTS idx_lexico_idioma  ON LexicoSemantico (Idioma);

-- Vista auxiliar con la clave semántica
CREATE VIEW IF NOT EXISTS v_LexicoSemantico AS
SELECT ls.*, s.Clave AS Semantica_Clave
FROM LexicoSemantico ls
JOIN Semantica s ON s.Semantica_Id = ls.Semantica_Id;

-- Trigger de updated_at
CREATE TRIGGER IF NOT EXISTS trg_lexico_updated AFTER UPDATE ON LexicoSemantico
BEGIN
  UPDATE LexicoSemantico SET updated_at = datetime('now') WHERE Lexico_Id = NEW.Lexico_Id;
END;
