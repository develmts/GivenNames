export async function getEmbedding(text: string, apiKey: string): Promise<number[]> {
  const response = await fetch("https://api-inference.huggingface.co/embeddings/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ inputs: text })
  });
  const json = await response.json();
  return json.embedding;
}
