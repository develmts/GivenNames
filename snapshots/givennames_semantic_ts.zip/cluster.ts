import KMeans from "kmeans-ts";

export function clusterEmbeddings(vectors: number[][], k: number) {
  const kmeans = new KMeans();
  return kmeans.cluster(vectors, k);
}
