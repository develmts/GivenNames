# GivenNames Semantic Clustering (TypeScript)
Prova de clustering semàntic de 500 noms utilitzant HuggingFace Inference API i TypeScript.

## Contingut
- `names.json`: Llista de noms en 25 idiomes, latinitzats
- `embedding.ts`: Generació d'embeddings via HuggingFace API
- `cluster.ts`: Algorisme KMeans per agrupar els vectors
- `main.ts`: Execució completa amb resultats per consola

## Requisits
- Node.js + TypeScript
- Registre gratuït a https://huggingface.co per obtenir un token API

## Execució
```bash
npm install
npx ts-node main.ts
```
