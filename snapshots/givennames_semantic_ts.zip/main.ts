import { getEmbedding } from "./embedding";
import { clusterEmbeddings } from "./cluster";
import names from "./names.json";
import * as fs from "fs";

const HF_API_TOKEN = process.env.HF_API_TOKEN || "PASTE_YOUR_TOKEN_HERE";

async function main() {
  const embeddings: number[][] = [];
  for (const name of names) {
    console.log("Embedding:", name);
    const vector = await getEmbedding(name, HF_API_TOKEN);
    embeddings.push(vector);
  }

  console.log("Clustering...");
  const clusters = clusterEmbeddings(embeddings, 5); // 5 clústers de prova
  clusters.clusters.forEach((c, idx) => {
    console.log(`Cluster ${idx}:`, c.map(i => names[i]));
  });

  fs.writeFileSync("result_clusters.json", JSON.stringify(clusters, null, 2));
}

main();
